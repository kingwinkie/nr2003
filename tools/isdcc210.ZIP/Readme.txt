isDcc v2.10
(c) 2001 Mr. Smith
MrSmith_@hotmail.com

This is a further modification of Andrew de Quinceys installshiled decompiler.
After my last extension I got several emails pointing out that there are some bugs in the original 
version of isDcc. I had a look at the code and here are the

bug fixes: 
1) I hope I fixed the problem of isDcc messing up labels !
2) Fixed the bug which printed "string" instead of the modulo sign "%".

While I was looking at the code I thought it would be nice if there would be cross references
for the labels, so that one can see from were a specific label is referenced. So here are

extensions:
cross references for labels.

So that�s it, and I think it should be good enough for some time.
Oh, yes one more tip what you can change in the *.ins file. Whereever you have a goto labelXXX 
statement you find in the scriptfile bytes like 70 xx yy where xx yy indicate the label number. So 
70 12 00 would be goto label18.

		Mr. Smith



=======================================================================================
isDcc v2.00
(c) 2000 Mr. Smith
MrSmith_@hotmail.com

This is a slightly extended version of Andrew de Quinceys installshield decompiler.

What�s the problem ?
If you currently have a problem with an Installshield script file you can use either use 
NaTzGULs and SiraXs wisdec, which is easy to use but has problems with many install shield scripts, 
or use isDcc which can handle most scripts but that one gives you "only" the source of the script 
which can�t be used immediately. Only with the install shield compiler itself can those scripts be 
compiled again. Often you need the right compiler version for your script version and even then it can
be tricky to compile it.

What is the solution ?
Version 2 of isDcc prints by default some additional information for each source line which can be
helpful. Like wisdec is prints the offset and opcode for each source line. If you figured out which line
you would like to change you open the script in a hexeditor and go to the offset of that line. The things 
you can change are comparisons. "if" statements like "if (lNumber1 = 0) then" have in their binary 
representation somewhere a 

91 for an  <
92 for an  >
93 for an <=
94 for an >= 
95 for an  =
96 for an !=

The other thing which can be changed are lines like "lNumber1 = lNumber0 = 12". Here you find at the 
binary level.

01 for an  <
02 for an  >
03 for an <=
04 for an >= 
05 for an  =
06 for an !=

After you made the necessary changes you have to correct the CRC which is best be done with mkcrc 
by Sebastian Apel which I have included.

Oh yes, if you need the old behaviour you can always start isdcc2 with 
isdcc2 -classic bla.ins

			have fun
			
			
			      Mr. Smith

P.S. The source is included and any change I made (except for include files) 
is marked by //version2 comments.


=======================================================================
isDcc v1.22
(c) 1998 Andrew de Quincey
http://www.tardis.ed.ac.uk/~adq
adq@tardis.ed.ac.uk


----------------------------------
Info:

This is an installshield decompiler. It supports all versions of 
installshield up to v5.5 (as far as I know).


----------------------------------
Usage:

To use it, type: 
       isdcc scriptfile.ins

The decompiled script will be output on stdout, so you can redirect it,
for example:
       isdcc setup.ins > setup.rul


----------------------------------
Problems:

You may have problems if you decompile a script compiled by one
installshield compiler, and attempt to recompile it with a different 
version of the compiler. For example, some functions in compiler version
5.00.00 have extra parameters than those in version 3.00.77. Some functions
have been removed from version 5.00.00 (for example CompressGet).

Since this program does not attempt to reconstruct the original higher-level
langauge operators from the ones in the file, what you get out will not
be exactly the same as the original code. The compiler appears to convert
the more complex langauge functions into (usually) a number of goto/comparison
statements. (e.g. "switch" is converted to a load of gotos/compares)

This may cause problems with functions, since in earlier versions of 
installshield, the compiler prevented you from have goto statements in 
functions, and this decompiler will generate these. 

However, installshield compiler 5.00.00 doesn't appear to check for this,
so generated scripts are usable.


----------------------------------
Bugs:

None that I know of, but I'm sure they're there. If you find one, please tell
me about it!


----------------------------------
Changes:

v1.1	Couple of output syntax bugfixes (call, DLL functions in IS3)
v1.2	Lots of bugfixes to do with labels, accessing invalid memory locations, and
	about 10 new opcodes added... all this from user feedback!
v1.21	Fix for falling off the end of file caused by changes introduced in v1.2
	Makefile added for using with gcc (various fixes in the progam for this too)
v1.22	Fix for crashing sometime (buggy alpha high level recovery code),
	and for missing last line of last function in the file

----------------------------------
Next Version:

Hopefully some kind of convertor to solve the problems with incompatibilities
between different versions of the installscript language.

Ability to reconstruct the higher-level language facilities from the compiled
file.


See also:
----------------------------------

http://www.installshield.com/


Acknowledgements:
----------------------------------

NaTzGUL/SiraX for the original Installshield decompiler (Wisdec). Without 
this excellent program, it would not have been possible to write this, since 
I would not have been able to fiddle with the compiled files and see what
did what.

freejazz@hotpop.com for his patches to fix labels properly...
croock@friko.onet.pl for another scipr with an unknown opcode...

And.. various anonymous donators who supplied me with other scripts, and patches
to fix memory problems.....

----------------------------------
Legal:

* Permission is granted to any individual or institution to use, copy, or 
  redistribute this software so long as all of the original files are 
  included unmodified, that it is not sold for profit, and that this copyright
  notice is retained.

* If you wish to use any code from this package in another product,
  or wish to sell it as a standalone product, you *must* contact me.

* Feel free to develop the code, but remember that you are not allowed to
  distribute the modified copies. Send me a copy of your additions, and
  I shall include them in the next version (indicating which parts of
  the code are whose, naturally).

* This software is provided "as is". The author annot be held responsible
  for any loss of data, or other misfortunes resulting from the use of this
  program.

* Likewise, the author cannot be held responsible for the use, or misuse of
  this software.
