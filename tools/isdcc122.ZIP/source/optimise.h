/* 
   isDcc
   (c) 1998 Andrew de Quincey
   adq@tardis.ed.ac.uk
   See README.TXT for copying/distribution/modification details.
*/

#ifndef OPTIMISE_H
#define OPTIMISE_H

#include "common.h"

extern void optimise(ISData* isData);

#endif
