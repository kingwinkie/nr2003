/* 
   isDcc
   (c) 1998 Andrew de Quincey
   adq@tardis.ed.ac.uk
   See README.TXT for copying/distribution/modification details.
*/



#ifndef HEADER_H
#define HEADER_H

#include "common.h"

extern void parseHeader(int fd, ISData* isData);

#endif
