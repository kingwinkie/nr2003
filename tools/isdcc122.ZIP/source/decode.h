/* 
   isDcc
   (c) 1998 Andrew de Quincey
   adq@tardis.ed.ac.uk
   See README.TXT for copying/distribution/modification details.
*/

#ifndef DECODE_H
#define DECODE_H

#include "common.h"

extern void initDecode(void);
extern void decode(int fd, ISData* isData);


#endif
