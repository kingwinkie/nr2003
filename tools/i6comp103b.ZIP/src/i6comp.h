///////////////////////////////////////////////////////////////////
// i6comp.h
//  
// InstallShield 5.xx Compression and Maintenance util
// fOSSiL - 1999
//
// InstallShield 6.xx Compression and Maintenance util
// Morlac - 2000
//
// *Any use is authorized, granted the proper credit is given*
//
// No support will be provided for this code
//

#ifndef _I6COMP_H
#define _I6COMP_H

typedef struct tagRWHANDLES {
	HANDLE hRead;
	HANDLE hWrite;
	DWORD  BytesIn;
	DWORD  BytesOut;
} RWHANDLES, *LPRWHANDLES;

typedef struct tagCABFILELIST {
	char   *FileName;
	WORD   VolIndex;
	DWORD  CabIndex;
	struct tagCABFILELIST* pNext;
} CABFILELIST, *LPCABFILELIST;

typedef struct tagDISKFILELIST {
	char   *FileName;
	DWORD  CabDirInd;
	LPSTR  DiskDir;
	LPSTR  CabDir;
	struct tagDISKFILELIST* pNext;
} DISKFILELIST, *LPDISKFILELIST;

typedef struct tagDIRARRAY {
	DWORD Count;
	LPSTR Dirs[];
} DIRARRAY, *LPDIRARRAY;

#endif // _I6COMP_H
