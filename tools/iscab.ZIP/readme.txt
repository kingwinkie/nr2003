The InstallShield Cabinet File Viewer (ISCabVu.exe) lets you select an 
InstallShield cabinet file and view its compressed files, file groups, 
components, and setup types and the properties of those items. It also 
lets you extract files from the cabinet file.

CAB file editor (iscab.exe) lets you modify cabinet files.


These two programs are extracted from InstallShield 6.21 package and 
"improved" by me so you don't have to know media password and component 
passwords.


PS. Run setup.reg first.


Player <player_pl@hotmail.com>
http://playtools.cjb.net